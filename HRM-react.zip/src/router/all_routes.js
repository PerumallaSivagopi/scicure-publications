export const all_routes = {
  login: '/login',
  index: '/index',
  onboarding: '/onboarding',
}