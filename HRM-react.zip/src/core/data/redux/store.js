import { configureStore } from '@reduxjs/toolkit'
import sidebarSlice from './sidebarSlice.js'
import themeSettingSlice from './themeSettingSlice.js'

const store = configureStore({
  reducer: {
    sidebarSlice,
    themeSetting: themeSettingSlice,
  },
  devTools: true,
})

export default store