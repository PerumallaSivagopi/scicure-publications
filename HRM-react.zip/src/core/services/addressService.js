import { apiClient } from './apiClient.js'

export const fetchAddressTypes = () => apiClient.get('/api/MasterData/AddressTypes')