import React, { Suspense, lazy } from 'react'

const createLazyComponent = (
  importFunc,
  fallback = <div className="loader-wrap"><div className="loader"></div></div>
) => {
  const LazyComponent = lazy(importFunc)
  return (props) => (
    <Suspense fallback={fallback}>
      <LazyComponent {...props} />
    </Suspense>
  )
}

export const Login = createLazyComponent(() => import('../feature-module/auth/login/login.jsx'))
export const AdminDashboard = createLazyComponent(() => import('../feature-module/pages/starter.jsx'))
export const OnboardingPage = createLazyComponent(() => import('../feature-module/pages/onboarding.jsx'))