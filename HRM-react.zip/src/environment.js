export const base_path = '/'
export const api_base = 'https://admin.qa.thehrpay.com'