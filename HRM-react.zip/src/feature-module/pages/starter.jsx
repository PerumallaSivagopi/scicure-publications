import React, { useState } from 'react'
import { fetchAddressTypes } from '../../core/services/addressService.js'

const StarterPage = () => {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const load = async () => {
    setLoading(true)
    setError('')
    try {
      const res = await fetchAddressTypes()
      setData(res)
    } catch (e) {
      setError(e?.message || 'Error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h2>Welcome</h2>
      <p>This is a starter page rendered after login.</p>
      <button onClick={load} style={{ padding: 10, background: '#1677ff', color: '#fff', border: 0, borderRadius: 6 }}>Load Address Types</button>
      {loading ? <div className="loader-wrap"><div className="loader"></div></div> : null}
      {error ? <div style={{ marginTop: 12, color: 'red' }}>{error}</div> : null}
      {data ? <pre style={{ marginTop: 12, background: '#f7f7f7', padding: 12, borderRadius: 6 }}>{JSON.stringify(data, null, 2)}</pre> : null}
    </div>
  )
}

export default StarterPage